import React, { useState, useEffect } from 'react';

function App() {
  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const maxTime = 4.5 * 60 * 60; // 4.5 hours in seconds
  const dailyMaxTime = 9 * 60 * 60; // 9 hours in seconds
  const weeklyMaxTime = 56 * 60 * 60; // 56 hours in seconds
  const biWeeklyMaxTime = 90 * 60 * 60; // 90 hours in seconds
  const [dailyTime, setDailyTime] = useState(0);
  const [weeklyTime, setWeeklyTime] = useState(0);
  const [biWeeklyTime, setBiWeeklyTime] = useState(0);
  const [lastWeekTime, setLastWeekTime] = useState(0);

  useEffect(() => {
    let interval;
    if (isRunning) {
      interval = setInterval(() => {
        setTime((prevTime) => prevTime + 1);
        setDailyTime((prevDailyTime) => prevDailyTime + 1);
        setWeeklyTime((prevWeeklyTime) => prevWeeklyTime + 1);
        setBiWeeklyTime((prevBiWeeklyTime) => prevBiWeeklyTime + 1);
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  useEffect(() => {
    if (time >= maxTime) {
      setIsRunning(false);
      alert('¡Tiempo máximo de conducción alcanzado!');
    }
  }, [time, maxTime]);

  useEffect(() => {
    const now = new Date();
    const dayOfWeek = now.getDay(); // 0 (Sunday) to 6 (Saturday)
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();

    // Reset weekly time on Monday at 00:00:00
    if (dayOfWeek === 1 && hours === 0 && minutes === 0 && seconds === 0) {
      setLastWeekTime(weeklyTime);
      setWeeklyTime(0);
    }
  }, [weeklyTime]);

  useEffect(() => {
    // Reset bi-weekly time every other Monday at 00:00:00
    const now = new Date();
    const dayOfWeek = now.getDay();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();
    const weekNumber = getWeekNumber(now);

    if (dayOfWeek === 1 && hours === 0 && minutes === 0 && seconds === 0 && weekNumber % 2 === 0) {
        setBiWeeklyTime(0);
    }
  }, []);

  const getWeekNumber = (date) => {
    const firstDayOfYear = new Date(date.getFullYear(), 0, 1);
    const pastDaysOfYear = (date - firstDayOfYear) / 86400000;
    return Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
  };

  const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes
      .toString()
      .padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleStart = () => {
    setIsRunning(true);
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setTime(0);
    setIsRunning(false);
  };

  const handleDailyReset = () => {
    setDailyTime(0);
  };

  const handleWeeklyReset = () => {
    if (window.confirm('¿Estás seguro de que quieres reiniciar el tiempo de conducción semanal?')) {
      setWeeklyTime(0);
    }
  };

  const handleBiWeeklyReset = () => {
    if (window.confirm('¿Estás seguro de que quieres reiniciar el tiempo de conducción bisemanal?')) {
      setBiWeeklyTime(0);
      setLastWeekTime(0);
    }
  };

  const remainingDailyTime = dailyMaxTime - dailyTime;
  const remainingWeeklyTime = weeklyMaxTime - weeklyTime;
  const remainingBiWeeklyTime = biWeeklyMaxTime - (biWeeklyTime + lastWeekTime);

  return (
    <div>
      <h1>{formatTime(time)}</h1>
      <button onClick={handleStart} disabled={isRunning || time >= maxTime}>
        Iniciar
      </button>
      <button onClick={handlePause} disabled={!isRunning}>
        Descanso
      </button>
      <button onClick={handleReset}>Reiniciar</button>

      <div style={{ marginTop: '20px', borderTop: '1px solid #ccc', paddingTop: '10px' }}>
        <h2>Tiempo de conducción diario</h2>
        <p>Límite diario: {formatTime(dailyMaxTime)}</p>
        <p>Tiempo restante: {remainingDailyTime > 0 ? formatTime(remainingDailyTime) : '00:00:00'}</p>
        <button onClick={handleDailyReset}>Reiniciar tiempo diario</button>
      </div>

      <div style={{ marginTop: '20px', borderTop: '1px solid #ccc', paddingTop: '10px' }}>
        <h2>Tiempo de conducción semanal</h2>
        <p>Límite semanal: {formatTime(weeklyMaxTime)}</p>
        <p>Tiempo restante: {remainingWeeklyTime > 0 ? formatTime(remainingWeeklyTime) : '00:00:00'}</p>
        <button onClick={handleWeeklyReset}>Reiniciar tiempo semanal</button>
      </div>

      <div style={{ marginTop: '20px', borderTop: '1px solid #ccc', paddingTop: '10px' }}>
        <h2>Tiempo de conducción bisemanal</h2>
        <p>Límite bisemanal: {formatTime(biWeeklyMaxTime)}</p>
         <p>Tiempo restante: {remainingBiWeeklyTime > 0 ? formatTime(remainingBiWeeklyTime) : '00:00:00'}</p>
         <button onClick={handleBiWeeklyReset}>Reiniciar tiempo bisemanal</button>
      </div>
    </div>
  );
}

export default App;
